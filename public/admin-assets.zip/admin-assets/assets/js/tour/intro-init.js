"use strict";
jQuery(document).ready(function() {
    var intro_start = {
        init: function() {
            introJs().start();
        }
    };
    intro_start.init()
});